<?php
/**
 * CSS properties list.
 *
 * @author 		WaspThemes
 * @category 	Options
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// arrow icon for list
$arrow_icon = "<span class='dashicons yp-arrow-icon dashicons-arrow-up'></span><span class='dashicons yp-arrow-icon dashicons-arrow-down'></span>";

/* ---------------------------------------------------- */
/* All CSS Options and settings							*/
/* ---------------------------------------------------- */
echo "<ul class='yp-editor-list'>
		
		<li class='text-option'>
		
			<h3>Text ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_select_markup(
					'font-family',
					'Font Family',
					"google-fonts.json",
					"inherit",
					'Set an font family.'
				)."
				
				
				".yp_get_select_markup(
					'font-weight',
					'Font Weight',
					array(
						'300' => 'Light'.' 300',
						'400' => 'normal'.' 400',
						'500' => 'Semi-Bold'.' 500',
						'600' => 'Bold'.' 600',
						'700' => 'Extra-Bold'.' 700'
					),
					"normal",
					'Sets how thick or thin characters in text should be displayed.'
				)."
	
				".yp_get_color_markup(
					'color',
					'Color',
					'Set the text color.'
				)."

				".yp_get_select_markup(
					'text-shadow',
					'Text Shadow',
					array(
						'rgba(0, 0, 0, 0.3) 0px 1px 1px' => 'Basic Shadow',
						'rgb(255, 255, 255) 1px 1px 0px, rgb(170, 170, 170) 2px 2px 0px' => 'Shadow Multiple',
						'rgb(255, 0, 0) -1px 0px 0px, rgb(0, 255, 255) 1px 0px 0px' => 'Anaglyph',
						'rgb(255, 255, 255) 0px 1px 1px, rgb(0, 0, 0) 0px -1px 1px' => 'Emboss',
						'rgb(255, 255, 255) 0px 0px 2px, rgb(255, 255, 255) 0px 0px 4px, rgb(255, 255, 255) 0px 0px 6px, rgb(255, 119, 255) 0px 0px 8px, rgb(255, 0, 255) 0px 0px 12px, rgb(255, 0, 255) 0px 0px 16px, rgb(255, 0, 255) 0px 0px 20px, rgb(255, 0, 255) 0px 0px 24px' => 'Neon',
						'rgb(0, 0, 0) 0px 1px 1px, rgb(0, 0, 0) 0px -1px 1px, rgb(0, 0, 0) 1px 0px 1px, rgb(0, 0, 0) -1px 0px 1px' => 'Outline'
					),
					"none",
					'Adds shadow to text.'
				)."

				".yp_get_slider_markup(
					'font-size',
					'Font Size',
					"inherit",
					0,        // decimals
					'8,100',   // px value
					'0,100',  // percentage value
					'1,6',     // Em value
					'Sets the size of a font.'
				)."
				
				".yp_get_slider_markup(
					'line-height',
					'Line Height',
					"inherit",
					1,        // decimals
					'0,100',   // px value
					'0,100',  // percentage value
					'1,6',     // Em value,
					'Set the leading.'
				)."
				
				".yp_get_radio_markup(
					'font-style',
					'Font Style',
					array(
						'normal' => 'Normal',
						'italic' => 'Italic'
					),
					"normal",
					'Specifies the font style for a text.'
				)."

				".yp_get_radio_markup(
					'text-align',
					'Text Align',
					array(
						'left' => 'left',
						'center' => 'center',
						'right' => 'right',
						'justify' => 'justify'
					),
					"start",
					'Specifies the horizontal alignment of text in an element.'
				)."
				
				".yp_get_radio_markup(
					'text-transform',
					'Text Transform',
					array(
						'uppercase' => 'uppercase',
						'lowercase' => 'lowercase',
						'capitalize' => 'capitalize'
					),
					"none",
					'Controls the capitalization of text.'					
				)."
			
				
				".yp_get_slider_markup(
					'letter-spacing',
					'Letter Spacing',
					"normal",
					1,        // decimals
					'-5,10',   // px value
					'0,100',  // percentage value
					'-1,3',     // Em value
					'Increases or decreases the space between characters in a text.'
				)."
				
				".yp_get_slider_markup(
					'word-spacing',
					'Word Spacing',
					"normal",
					1,        // decimals
					'-5,20',   // px value
					'0,100',  // percentage value
					'-1,3',     // Em value,
					'increases or decreases the white space between words.'
				)."

				".yp_get_radio_markup(
					'text-decoration',
					'Text Decoration',
					array(
						'overline' => 'overline',
						'line-through' => 'line-through',
						'underline' => 'underline'
					),
					"none",
					'Specifies the decoration added to text.'
				)."

				".yp_get_slider_markup(
					'text-indent',
					'Text Indent',
					'0',
					0,        // decimals
					'-50,50',   // px value
					'-100,100',  // percentage value
					'-15,15',     // Em value
					'Specifies the indentation of the first line in a text-block.'
				)."

				".yp_get_radio_markup(
					'word-wrap',
					'Word Wrap',
					array(
						'normal' => 'normal',
						'break-word' => 'break-word'
					),
					"normal",
					'Allows long words to be able to be broken and wrap onto the next line.'
				)."
				
			</div>
		</li>
		
		<li class='background-option'>
			<h3>Background ".$arrow_icon."</h3>
			<div class='yp-this-content'>
				
				".yp_get_color_markup(
					'background-color',
					'Background Color',
					'Sets the background color of an element.'
				)."
				
				".yp_get_input_markup(
					'background-image',
					'Background Image',
					"none",
					'Sets background image for an element.'
				)."

				".yp_get_radio_markup(
					'background-clip',
					'Background Clip',
					array(
						'text' => 'text',
						'padding-box' => 'padding-box',
						'content-box' => 'content-box'
					),
					"border-box",
					"defines how far the background should extend within the element."
				)."

				".yp_get_radio_markup(
					'background-blend-mode',
					'BG. Blend Mode',
					array(
						'multiply' => 'multiply',
						'darken' => 'darken',
						'luminosity' => 'luminosity'
					),
					"normal",
					'Defines the blending mode of background color and image.'
				)."

				".yp_get_slider_markup(
					'background-position-x',
					'BG. Horizontal Position',
					"0%",
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value,
					'Sets the horizontal starting position of a background image.'
				)."

				".yp_get_slider_markup(
					'background-position-y',
					'BG. Vertical Position',
					"0%",
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value,
					'Sets the vertical starting position of a background image.'
				)."

				".yp_get_radio_markup(
					'background-size',
					'Background Size',
					array(
						'length' => 'length',
						'cover' => 'cover',
						'contain' => 'contain'
					),
					"auto auto",
					'The size of the background image.'
				)."				
				
				".yp_get_radio_markup(
					'background-repeat',
					'Background Repeat',
					array(
						'repeat-x' => 'repeat-x',
						'repeat-y' => 'repeat-y',
						'no-repeat' => 'no-repeat'
					),
					"repeat",
					'Sets if background image will be repeated.'
				)."
				
				".yp_get_radio_markup(
					'background-attachment',
					'BG. Attachment',
					array(
						'fixed' => 'fixed',
						'local' => 'local'
					),
					"scroll",
					'Sets whether a background image is fixed or scrolls with the rest of the page.'
				)."				
				
			</div>
		</li>
		
		<li class='margin-option'>
			<h3>Margin ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				<div class='lock-btn'></div>

				".yp_get_slider_markup(
					'margin-left',
					'Margin Left',
					"auto",
					0,        // decimals
					'-50,200',   // px value
					'-100,100',  // percentage value
					'-6,26',     // Em value,
					'Sets the left margin of an element.'
				)."
				
				".yp_get_slider_markup(
					'margin-right',
					'Margin Right',
					"auto",
					0,        // decimals
					'-50,200',   // px value
					'-100,100',  // percentage value
					'-6,26',     // Em value
					'Sets the right margin of an element.'
				)."

				".yp_get_slider_markup(
					'margin-top',
					'Margin Top',
					'0',
					0,        // decimals
					'-50,200',   // px value
					'-100,100',  // percentage value
					'-6,26',     // Em value
					'Sets the top margin of an element.'
				)."
				
				".yp_get_slider_markup(
					'margin-bottom',
					'Margin Bottom',
					'0',
					0,        // decimals
					'-50,200',   // px value
					'-100,100',  // percentage value
					'-6,26',     // Em value
					'Sets the bottom margin of an element.'
				)."
				
				
				
			</div>
		</li>
		
		<li class='padding-option'>
			<h3>Padding ".$arrow_icon."</h3>
			<div class='yp-this-content'>
				
				<div class='lock-btn'></div>

				".yp_get_slider_markup(
					'padding-left',
					'Padding Left',
					'0',
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value
					'Sets the left padding (space) of an element.'
				)."

				".yp_get_slider_markup(
					'padding-right',
					'Padding Right',
					'0',
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value
					'Sets the right padding (space) of an element.'
				)."

				".yp_get_slider_markup(
					'padding-top',
					'Padding Top',
					'0',
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value
					'Sets the top padding (space) of an element.'
				)."
				
				".yp_get_slider_markup(
					'padding-bottom',
					'Padding Bottom',
					'0',
					0,        // decimals
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value
					'Sets the bottom padding (space) of an element.'
				)."

				
				
			
			</div>
		</li>

		
		<li class='border-option'>
			<h3>Border ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_radio_markup(
					'border-type',
					'Border Type',
					array(
						'all' => 'all',
						'top' => 'top',
						'right' => 'right',
						'bottom' => 'bottom',
						'left' => 'left'
					),
					"none",
					'Select the border you want to edit.'
				)."
				
				<div class='yp-border-all-section'>

					".yp_get_radio_markup(
						'border-style',
						'Border Style',
						array(
							'solid' => 'solid',
							'dotted' => 'dotted',
							'dashed' => 'dashed',
							'hidden' => 'hidden'
						),
						"none",
						'Sets the style of an element four borders.'
					)."
					
					
					".yp_get_slider_markup(
						'border-width',
						'Border Width',
						'medium',
						0,        // decimals
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Sets the width of an element four borders.'
					)."

					".yp_get_color_markup(
						'border-color',
						'Border Color',
						'Sets the color of an element four borders.'
					)."

				</div>
				
				<div class='yp-border-top-section'>

					".yp_get_radio_markup(
						'border-top-style',
						'Border Top Style',
						array(
							'solid' => 'solid',
							'dotted' => 'dotted',
							'dashed' => 'dashed',
							'hidden' => 'hidden'
						),
						"none",
						'Sets the style of an element top border.'
					)."
					
					".yp_get_slider_markup(
						'border-top-width',
						'Border Top Width',
						'medium',
						0,        // decimals
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Sets the width of an element top border.'
					)."

					".yp_get_color_markup(
						'border-top-color',
						'Border Top Color',
						'Sets the color of an element top border.'
					)."

				</div>
				
				<div class='yp-border-right-section'>

					".yp_get_radio_markup(
						'border-right-style',
						'Border Right Style',
						array(
							'solid' => 'solid',
							'dotted' => 'dotted',
							'dashed' => 'dashed',
							'hidden' => 'hidden'
						),
						"none",
						'Sets the style of an element right border.'
					)."
					
					".yp_get_slider_markup(
						'border-right-width',
						'Border Right Width',
						'medium',
						0,        // decimals
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Sets the width of an element right border.'
					)."

					".yp_get_color_markup(
						'border-right-color',
						'Border Right Color',
						'Sets the color of an element right border.'
					)."

				</div>
				
				
				<div class='yp-border-bottom-section'>
				
					".yp_get_radio_markup(
						'border-bottom-style',
						'Border Bottom Style',
						array(
							'solid' => 'solid',
							'dotted' => 'dotted',
							'dashed' => 'dashed',
							'hidden' => 'hidden'
						),
						"none",
						'Sets the style of an element bottom border.'
					)."
					
					".yp_get_slider_markup(
						'border-bottom-width',
						'Border Bottom Width',
						'medium',
						0,        // decimals
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Sets the width of an element bottom border.'
					)."

					".yp_get_color_markup(
						'border-bottom-color',
						'Border Bottom Color',
						'Sets the color of an element bottom border.'
					)."

				</div>
				
				
				<div class='yp-border-left-section'>

					".yp_get_radio_markup(
						'border-left-style',
						'Border Left Style',
						array(
							'solid' => 'solid',
							'dotted' => 'dotted',
							'dashed' => 'dashed',
							'hidden' => 'hidden'
						),
						"none",
						'Sets the style of an element left border.'
					)."
					
					".yp_get_slider_markup(
						'border-left-width',
						'Border Left Width',
						'medium',
						0,        // decimals
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Sets the width of an element left border.'
					)."

					".yp_get_color_markup(
						'border-left-color',
						'Border Left Color',
						'Sets the color of an element left border.'
					)."
				
				</div>
				
			</div>
		</li>
		
		<li class='border-radius-option'>
			<h3>Border Radius ".$arrow_icon."</h3>
			<div class='yp-this-content'>
				
				<div class='lock-btn'></div>
				".yp_get_slider_markup(
					'border-top-left-radius',
					'Top Left Radius',
					'0',
					"0",        // decimals
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Defines the radius of the top-left corner.'
				)."
				
				".yp_get_slider_markup(
					'border-top-right-radius',
					'Top Right Radius',
					'0',
					"0",        // decimals
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Defines the radius of the top-right corner.'
				)."
				
				".yp_get_slider_markup(
					'border-bottom-right-radius',
					'Bottom Right Radius',
					'0',
					"0",        // decimals
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Defines the radius of the bottom-right corner.'
				)."

				".yp_get_slider_markup(
					'border-bottom-left-radius',
					'Bottom Left Radius',
					'0',
					"0",        // decimals
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Defines the radius of the bottom-left corner.'
				)."
				
				
			</div>
		</li>
		
		<li class='position-option'>
			<h3>Position ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_slider_markup(
					'z-index',
					'Z Index',
					"auto",
					0,        // decimals
					'-10,1000',   // px value
					'-10,1000',  // percentage value
					'-10,1000',     // Em value
					'Specifies the stack order of an element. Z index only works on positioned elements (absolute, relative, or fixed).'
				)."	
				
				".yp_get_radio_markup(
					'position',
					'Position',
					array(
						'relative' => 'relative',
						'absolute' => 'absolute',
						'fixed' => 'fixed'
					),
					"static",
					'Specifies the type of positioning method used for an element.'
					
				)."
				
				".yp_get_slider_markup(
					'top',
					'Top',
					"auto",
					0,        // decimals
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'For absolutely: positioned elements, the top property sets the top edge of an element to a unit above/below the top edge of its containing element.<br><br>For relatively: positioned elements, the top property sets the top edge of an element to a unit above/below its normal position.'
				)."

				".yp_get_slider_markup(
					'left',
					'Left',
					"auto",
					0,        // decimals
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'For absolutely: positioned elements, the left property sets the left edge of an element to a unit to the left/right of the left edge of its containing element.<br><br>For relatively: positioned elements, the left property sets the left edge of an element to a unit to the left/right to its normal position.'
				)."

				".yp_get_slider_markup(
					'bottom',
					'Bottom',
					"auto",
					0,        // decimals
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'For absolutely: positioned elements, the bottom property sets the bottom edge of an element to a unit above/below the bottom edge of its containing element.<br><br>For relatively: positioned elements, the bottom property sets the bottom edge of an element to a unit above/below its normal position.'
				)."
				
				".yp_get_slider_markup(
					'right',
					'Right',
					"auto",
					0,        // decimals
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'For absolutely: positioned elements, the right property sets the right edge of an element to a unit to the left/right of the right edge of its containing element.<br><br>For relatively: positioned elements, the right property sets the right edge of an element to a unit to the left/right to its normal position.'
				)."
				
			</div>
		</li>
		
		<li class='size-option'>
			<h3>Size <span class='yp-badge yp-lite'>Pro</span> ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_slider_markup(
					'width',
					'Width',
					"auto",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Sets the width of an element.'
				)."
				
				".yp_get_slider_markup(
					'height',
					'Height',
					"auto",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Sets the height of an element'
				)."

				".yp_get_radio_markup(
					'box-sizing',
					'Box Sizing',
					array(
						'border-box' => 'border-box',
						'content-box' => 'content-box'
					),
					false,
					'Defines how the width and height of an element are calculated: should they include padding and borders, or not.'
				)."
				
				".yp_get_slider_markup(
					'min-width',
					'Min Width',
					"initial",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Set the minimum width of an element.'
				)."

				".yp_get_slider_markup(
					'min-height',
					'Min Height',
					"initial",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',    // Em value
					'Set the minimum height of an element.'
				)."
				
				".yp_get_slider_markup(
					'max-width',
					'Max Width',
					"none",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Set the maximum width of an element.'
				)."
				
				".yp_get_slider_markup(
					'max-height',
					'Max Height',
					"none",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Set the maximum height of an element.'
				)."
				
				
			</div>
		</li>

		<li class='flex-option'>
			<h3>Flexbox ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_radio_markup(
					'flex-direction',
					'Flex Direction',
					array(
						'row-reverse' => 'row-reverse',
						'column' => 'column',
						'column-reverse' => 'column-reverse'
					),
					'row',
					'Specifies the direction of the flexible items.'
					
				)."

				".yp_get_radio_markup(
					'flex-wrap',
					'Flex Wrap',
					array(
						'wrap' => 'wrap',
						'wrap-reverse' => 'wrap-reverse'
					),
					'nowrap',
					'Specifies whether the flexible items should wrap or not.'
					
				)."

				".yp_get_select_markup(
					'justify-content',
					'Justify Content',
					array(
						'flex-start' => 'flex-start',
						'flex-end' => 'flex-end',
						'center' => 'center',
						'space-between' => 'space-between',
						'space-around' => 'space-around',
					),
					"normal",
					'Aligns the flexible containers items when the items do not use all available space on the main-axis (horizontally).'
				)."


				".yp_get_select_markup(
					'align-items',
					'Align Items',
					array(
						'stretch' => 'stretch',
						'center' => 'center',
						'flex-start' => 'flex-start',
						'flex-end' => 'flex-end',
						'baseline' => 'baseline',
					),
					"normal",
					'Specifies the default alignment for items inside the flexible container.'
				)."

				".yp_get_select_markup(
					'align-content',
					'Align Content',
					array(
						'stretch' => 'stretch',
						'center' => 'center',
						'flex-start' => 'flex-start',
						'flex-end' => 'flex-end',
						'space-between' => 'space-between',
						'space-around' => 'space-around',
					),
					"normal",
					'Modifies the behavior of the flex-wrap property. It is similar to align-items, but instead of aligning flex items, it aligns flex lines.'
				)."


				".yp_get_slider_markup(
					'flex-basis',
					'Flex Basis',
					"auto",
					0,        // decimals
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Specifies the initial length of a flexible item.'
				)."

				".yp_get_select_markup(
					'align-self',
					'Align Self',
					array(
						'stretch' => 'stretch',
						'center' => 'center',
						'flex-start' => 'flex-start',
						'flex-end' => 'flex-end',
						'baseline' => 'baseline',
					),
					"auto",
					'Specifies the alignment for the selected item inside the flexible container.'
				)."

				".yp_get_slider_markup(
					'flex-grow',
					'Flex Grow',
					'0',
					0,        // decimals
					'0,20',   // px value
					'0,20',  // percentage value
					'0,20',     // Em value
					'Specifies how much the item will grow relative to the rest of the flexible items inside the same container.'
				)."

				".yp_get_slider_markup(
					'flex-shrink',
					'Flex Shrink',
					'1',
					0,        // decimals
					'0,20',   // px value
					'0,20',  // percentage value
					'0,20',     // Em value
					'Specifies how the item will shrink relative to the rest of the flexible items inside the same container.'
				)."

			</div>
		</li>
		
		<li class='lists-option'>
			<h3>Lists ".$arrow_icon."</h3>
			<div class='yp-this-content'>

				".yp_get_select_markup(
					'list-style-type',
					'List Style Type'
					,array(
						'disc' => 'disc',
						'circle' => 'circle',
						'decimal' => 'decimal',
						'lower-alpha' => 'lower alpha',
						'upper-alpha' => 'upper alpha',
						'upper-roman' => 'upper roman'
					),
					"none",
					'Specifies the type of list-item marker in a list.'
				)."

				".yp_get_input_markup(
					'list-style-image',
					'List Style Image',
					"none",
					'Replaces the list-item marker with an image.'
				)."

				".yp_get_radio_markup(
					'list-style-position',
					'List Style Position',
					array(
						'inside' => 'inside',
						'outside' => 'outside'
					),
					"none",
					'Specifies if the list-item markers should appear inside or outside the content flow.'
				)."	

			</div>
		</li>

		<li class='animation-option'>
			<h3>Animation <span class='yp-badge yp-lite'>Pro</span> <span class='yp-badge yp-anim-recording'>Rec</span> ".$arrow_icon."</h3>
			<div class='yp-this-content'>
				
				";

				// Dev Animation Tools Filter
				$filter_animation_tools = apply_filters( 'yp_animation_tools', TRUE);

				// If animation Generator Open
				if($filter_animation_tools){
					echo "<div class='animation-links-control yp-just-desktop'>
					<a class='yp-advanced-link yp-special-css-link yp-just-desktop yp-add-animation-link'>Create Animation</a>
					</div>";
				}

				// Default animations
				$animations = array(
					'none' => 'none',
					'bounce' => 'bounce',
					'spin' => 'spin',
					'flash' => 'flash',
					'swing' => 'swing',
					'pulse' => 'pulse',
					'rubberBand' => 'rubberBand',
					'shake' => 'shake',
					'tada' => 'tada',
					'wobble' => 'wobble',
					'jello' => 'jello',
					'bounceIn' => 'bounceIn',
						
					'spaceInUp' => 'spaceInUp',
					'spaceInRight' => 'spaceInRight',
					'spaceInDown' => 'spaceInDown',
					'spaceInLeft' => 'spaceInLeft',
					'push' => 'push',
					'pop' => 'pop',
					'bob' => 'bob',
					'wobble-horizontal' => 'wobble-horizontal',
											
					'bounceInDown' => 'bounceInDown',
					'bounceInLeft' => 'bounceInLeft',
					'bounceInRight' => 'bounceInRight',
					'bounceInUp' => 'bounceInUp',
					'fadeIn' => 'fadeIn',
					'fadeInDown' => 'fadeInDown',
					'fadeInDownBig' => 'fadeInDownBig',
					'fadeInLeft' => 'fadeInLeft',
					'fadeInLeftBig' => 'fadeInLeftBig',
					'fadeInRight' => 'fadeInRight',
					'fadeInRightBig' => 'fadeInRightBig',
					'fadeInUp' => 'fadeInUp',
					'fadeInUpBig' => 'fadeInUpBig',
					'flipInX' => 'flipInX',
					'flipInY' => 'flipInY',
					'lightSpeedIn' => 'lightSpeedIn',
					'rotateIn' => 'rotateIn',
					'rotateInDownLeft' => 'rotateInDownLeft',
					'rotateInDownRight' => 'rotateInDownRight',
					'rotateInUpLeft' => 'rotateInUpLeft',
					'rotateInUpRight' => 'rotateInUpRight',
					'rollIn' => 'rollIn',
					'zoomIn' => 'zoomIn',
					'zoomInDown' => 'zoomInDown',
					'zoomInLeft' => 'zoomInLeft',
					'zoomInRight' => 'zoomInRight',
					'zoomInUp' => 'zoomInUp',
					'slideInDown' => 'slideInDown',
					'slideInLeft' => 'slideInLeft',
					'slideInRight' => 'slideInRight',
					'slideInUp' => 'slideInUp'
				);

				// Add dynamic animations.
				$all_options =  wp_load_alloptions();
				foreach($all_options as $name => $value){
					if(stristr($name, 'yp_anim')){
						$name = str_replace("yp_anim_", "", $name);
						$animations[$name] = ucwords(strtolower($name));
					}
				}
				
				echo " ".yp_get_select_markup(
					'animation-name',
					'Animation',
					$animations,
					"none",
					'Adds an animation to an element.'
				)."
				
				".yp_get_select_markup(
					'animation-play',
					'Condition',
					array(
						'yp_onscreen' => 'onScreen',
						'yp_hover' => 'Hover',
						'yp_click' => 'Click',
						'yp_focus' => 'Focus'
					),
					'yp_onscreen',
					'OnScreen: Playing animation when element visible on screen.<br><br>Hover: Playing animation when mouse on element.<br><br>Click: Playing animation when element clicked.<br><br>Focus: Playing element when click on an text field.'
				)."
				
				".yp_get_select_markup(
					'animation-iteration-count',
					'Animation Iteration',
					array(
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
						'infinite' => 'infinite'
					),
					'1',
					'Specifies the number of times an animation should be played.'
				)."

				".yp_get_slider_markup(
					'animation-duration',
					'Animation Duration',
					'0s',
					2,        // decimals
					'1,10',   // px value
					'1,10',   // percentage value
					'1,10',   // Em/ms value
					'Defines how long an animation should take to complete one cycle.'
				)."

				".yp_get_slider_markup(
					'animation-delay',
					'Animation Delay',
					'0s',
					2,        // decimals
					'0,10',   // px value
					'0,10',  // percentage value
					'0,10',     // Em/ms value
					'Specifies a delay for the start of an animation.'
				)."

				".yp_get_radio_markup(
					'animation-fill-mode',
					'Animation Fill Mode',
					array(
						'forwards' => 'forwards',
						'backwards' => 'backwards',
						'both' => 'both',
					),
					"none",
					'Sets the state of the end animation when the animation is not running.'
				)."		
				
			</div>
		</li>
		
		<li class='box-shadow-option'>
			<h3>Box Shadow ".$arrow_icon."</h3>
			<div class='yp-this-content'>
			
				".yp_get_color_markup(
					'box-shadow-color',
					'Color',
					'Sets color of the shadow.'
				)."
				
				".yp_get_slider_markup(
					'box-shadow-blur-radius',
					'Blur Radius',
					'0',
					0,        	// decimals
					'0,50',   // px value
					'0,50',  // percentage value
					'0,50',     // Em value
					'Sets blur radius of the shadow.'
				)."
				
				".yp_get_slider_markup(
					'box-shadow-spread',
					'Spread',
					'0',
					0,        	// decimals
					'-50,100',   // px value
					'-50,100',  // percentage value
					'-50,100',     // Em value
					'Set size of the shadow.'
				)."

				".yp_get_radio_markup(
					'box-shadow-inset',
					'Position',
					array(
						'no' => 'Outer',
						'inset' => 'Inner'
					),
					false,
					'Defines whether the shadow is inside or outside.'
				)."		

				".yp_get_slider_markup(
					'box-shadow-horizontal',
					'Horizontal Length',
					'0',
					0,        // decimals
					'-50,50',   // px value
					'-50,50',  // percentage value
					'-50,50',     // Em value
					'Sets horizontal length of the shadow.'
				)."
				
				".yp_get_slider_markup(
					'box-shadow-vertical',
					'Vertical Length',
					'0',
					0,        	// decimals
					'-50,50',   // px value
					'-50,50',  // percentage value
					'-50,50',     // Em value
					'Sets vertical length of the shadow.'
				)."

			</div>
		</li>
		
		<li class='extra-option'>
			<h3>Extra ".$arrow_icon."</h3>
			<div class='yp-this-content'>";

				// Transform CSS Filter
			    $filter_status = apply_filters( 'yp_property__filter', TRUE);

			    // Transform is valid
			    if($filter_status){

				    echo "<a class='yp-advanced-link yp-top yp-special-css-link yp-filter-link'>Filters</a>
					<div class='yp-advanced-option yp-special-css-area yp-filter-area'>

					".yp_get_slider_markup(
						'blur-filter',
						'Blur',
						'0',
						2,        // decimals
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10'     // Em value
					)."
					
					".yp_get_slider_markup(
						'brightness-filter',
						'Brightness',
						'0',
						2,        // decimals
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10'     // Em value
					)."
					
					".yp_get_slider_markup(
						'grayscale-filter',
						'Grayscale',
						'0',
						2,        // decimals
						'0,1',   // px value
						'0,1',  // percentage value
						'0,1'     // Em value
					)."
					
					".yp_get_slider_markup(
						'contrast-filter',
						'Contrast',
						'0',
						2,        // decimals
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10'     // Em value
					)."
					
					".yp_get_slider_markup(
						'hue-rotate-filter',
						'Hue Rotate',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."
					
					".yp_get_slider_markup(
						'saturate-filter',
						'Saturate',
						'0',
						2,        // decimals
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10'     // Em value
					)."
					
					".yp_get_slider_markup(
						'sepia-filter',
						'Sepia',
						'0',
						2,        // decimals
						'0,1',   // px value
						'0,1',  // percentage value
						'0,1'     // Em value
					)."

					</div>";

				}

				// Transform CSS Filter
			    $transform_status = apply_filters( 'yp_property__transform', TRUE);

			    // Transform is valid
			    if($transform_status){

				    echo "<a class='yp-advanced-link yp-top yp-special-css-link yp-transform-link'>Transform</a>
					<div class='yp-advanced-option yp-special-css-area yp-transform-area'>
					".yp_get_slider_markup(
						'scale-transform',
						'Scale',
						'0',
						2,        // decimals
						'0,5',   // px value
						'0,5',  // percentage value
						'0,5'     // Em value
					)."
					
					".yp_get_slider_markup(
						'rotate-transform',
						'Rotate',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."

					".yp_get_slider_markup(
						'rotatex-transform',
						'Rotate X',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."

					".yp_get_slider_markup(
						'rotatey-transform',
						'Rotate Y',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."

					".yp_get_slider_markup(
						'rotatez-transform',
						'Rotate Z',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."
					
					".yp_get_slider_markup(
						'translate-x-transform',
						'Translate X',
						'0',
						0,        // decimals
						'-50,50',   // px value
						'-50,50',  // percentage value
						'-50,50'     // Em value
					)."
					
					".yp_get_slider_markup(
						'translate-y-transform',
						'Translate Y',
						'0',
						0,        // decimals
						'-50,50',   // px value
						'-50,50',  // percentage value
						'-50,50'     // Em value
					)."
					
					".yp_get_slider_markup(
						'skew-x-transform',
						'Skew X',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."
					
					".yp_get_slider_markup(
						'skew-y-transform',
						'skew Y',
						'0',
						0,        // decimals
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360'     // Em value
					)."

					".yp_get_slider_markup(
						'perspective',
						'Perspective',
						'0',
						0,        // decimals
						'0,1000',   // px value
						'0,100',  // percentage value
						'0,62'     // Em value
					)."

					</div>";

				}
				
				
				echo "".yp_get_slider_markup(
					'opacity',
					'Opacity',
					'1',
					2,        // decimals
					'0,1',   // px value
					'0,1',  // percentage value
					'0,1',     // Em value
					'Sets the opacity level for an element.'
				)."

				".yp_get_select_markup(
					'display',
					'Display',
					array(
						'block' => 'block',
						'flex' => 'flex',
						'inline' => 'inline',
						'inline-block' => 'inline-block',
						'inline-flex' => 'inline-flex',
						'table-cell' => 'table-cell',
						'none' => 'none',
					),
					"inline",
					'Specifies the type of box used for an element.'
				)."

				".yp_get_select_markup(
					'cursor',
					'Cursor',
					array(
						'alias' => 'alias',
						'all-scroll' => 'All Scroll',
						'copy' => 'Copy',
						'crosshair' => 'CrossHair',
						'grab' => 'Grab',
						'grabbing' => 'Grabbing',
						'help' => 'Help',
						'not-allowed' => 'Not Allowed',
						'pointer' => 'Pointer',
						'progress' => 'Progress',
						'text' => 'Text',
						'wait' => 'Wait',
						'zoom-in' => 'Zoom In',
						'zoom-out' => 'Zoom Out'
					),
					"auto",
					'Specifies the type of cursor to be displayed when pointing on an element.'
				)."
				
				".yp_get_radio_markup(
					'float',
					'Float',
					array(
						'left' => 'left',
						'right' => 'right'
					),
					"none",
					'Specifies how an element should float.'
				)."

				".yp_get_radio_markup(
					'clear',
					'Clear',
					array(
						'left' => 'left',
						'right' => 'right',
						'both' => 'both'
					),
					"none",
					'Specifies on which sides of an element floating elements are not allowed to float.'
				)."

				".yp_get_radio_markup(
					'visibility',
					'Visibility',
					array(
						'visible' => 'visible',
						'hidden' => 'hidden'
					),
					"initial",
					'Specifies whether or not an element is visible.'
				)."

				".yp_get_radio_markup(
					'pointer-events',
					'Pointer Events',
					array(
						'auto' => 'auto',
						'none' => 'none'
					),
					"auto",
					'Specifies under what circumstances (if any) a particular graphic element can become the target of mouse events.'
				)."
				
				".yp_get_radio_markup(
					'overflow-x',
					'Overflow X',
					array(
						'hidden' => 'hidden',
						'scroll' => 'scroll',
						'auto' => 'auto'
					),
					"visible",
					'Specifies what to do with the left/right edges of the content - if it overflows the elements content area.'
				)."
				
				".yp_get_radio_markup(
					'overflow-y',
					'Overflow Y',
					array(
						'hidden' => 'hidden',
						'scroll' => 'scroll',
						'auto' => 'auto'
					),
					"visible",
					'specifies what to do with the bottom edges of the content - if it overflows the elements content area.'
				)."
				
				
			</div>

		</li>
			
	</ul>";