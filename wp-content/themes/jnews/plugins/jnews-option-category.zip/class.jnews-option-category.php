<?php
/**
 * @author Jegtheme
 */

use JNews\Form\FormControl;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'JNews_Option_Category' ) )
{
    class JNews_Option_Category
    {
        private static $instance;

        private $prefix = 'jnews_category_';

        public static function getInstance()
        {
            if (null === static::$instance)
            {
                static::$instance = new static();
            }
            return static::$instance;
        }

        private function __construct()
        {
            $this->setup_hook();
        }

        protected function setup_hook()
        {
            add_action( 'admin_enqueue_scripts',            array( $this, 'load_script' ) );
            add_action( 'edit_category_form',               array( $this, 'render_options' ) );
            add_action( 'edit_category',                    array( $this, 'save_category' ) );
            add_action( 'jnews_before_inline_dynamic_css',  array( $this, 'override_theme_mod' ) );

            add_filter( 'jnews_category_sidebar',                           array( $this, 'get_category_sidebar' ), 10, 2 );
	        add_filter( 'jnews_category_second_sidebar',                    array( $this, 'get_category_second_sidebar' ), 10, 2 );
            add_filter( 'jnews_category_page_layout',                       array( $this, 'get_content_page_layout' ), 10, 2 );
            add_filter( 'jnews_category_sticky_sidebar',                    array( $this, 'get_sticky_sidebar' ), 10, 2 );
            add_filter( 'jnews_category_content_pagination_show_pageinfo',  array( $this, 'get_content_pagination_pageinfo' ), 10, 2 );
            add_filter( 'jnews_category_content_pagination_show_navtext',   array( $this, 'get_content_pagination_navtext' ), 10, 2 );
            add_filter( 'jnews_category_content_pagination_align',          array( $this, 'get_content_pagination_align' ), 10, 2 );
            add_filter( 'jnews_category_content_pagination_limit',          array( $this, 'get_content_pagination_limit' ), 10, 2 );
            add_filter( 'jnews_category_content_pagination',                array( $this, 'get_content_pagination' ), 10, 2 );
            add_filter( 'jnews_category_content_date_custom',               array( $this, 'get_content_date_custom' ), 10, 2 );
            add_filter( 'jnews_category_content_date',                      array( $this, 'get_content_date' ), 10, 2 );
            add_filter( 'jnews_category_content_excerpt',                   array( $this, 'get_content_excerpt' ), 10, 2 );
            add_filter( 'jnews_category_content',                           array( $this, 'get_content_type' ), 10, 2 );
            add_filter( 'jnews_category_hero_date_custom',                  array( $this, 'get_hero_date_custom' ), 10, 2 );
            add_filter( 'jnews_category_hero_date',                         array( $this, 'get_hero_date' ), 10, 2 );
            add_filter( 'jnews_category_hero_margin',                       array( $this, 'get_hero_margin' ), 10, 2 );
            add_filter( 'jnews_category_hero_style',                        array( $this, 'get_hero_style' ), 10, 2 );
            add_filter( 'jnews_category_hero',                              array( $this, 'get_hero_type' ), 10, 2 );
            add_filter( 'jnews_category_hero_show',                         array( $this, 'get_show_hero' ), 10, 2 );
            add_filter( 'jnews_category_header_bg_image',                   array( $this, 'get_header_image' ), 10, 2 );
            add_filter( 'jnews_category_header_style',                      array( $this, 'get_header_style' ), 10, 2 );
            add_filter( 'jnews_category_header_bg_color',                   array( $this, 'get_header_background' ), 10, 2 );
            add_filter( 'jnews_category_header',                            array( $this, 'get_header_type' ), 10, 2 );
	        add_filter( 'jnews_category_boxed',                             array( $this, 'get_category_boxed' ), 10, 2 );
	        add_filter( 'jnews_category_boxed_shadow',                      array( $this, 'get_category_boxed_shadow' ), 10, 2 );
	        add_filter( 'jnews_category_box_shadow',                        array( $this, 'get_category_box_shadow' ), 10, 2 );
        }

        public function override_theme_mod()
        {
            $options = get_option( $this->prefix . 'category_override_color', array() );

            // need to include the content right here
            add_filter('jeg_register_lazy_section', array($this, 'register_lazy_category'));

            foreach ( $options as $key => $option )
            {
                if ( $option )
                {
                    $this->generate_theme_mod_filter( 'jnews_category_override_color_', 'category_override_color', $key );
                    $this->generate_theme_mod_filter( 'jnews_category_color_', 'category_bg_color', $key );
                    $this->generate_theme_mod_filter( 'jnews_category_text_color_', 'category_text_color', $key );
                }
            }
        }

        public function register_lazy_category($result)
        {
            $options = get_option( $this->prefix . 'category_override_color', array() );

            foreach ( $options as $key => $option )
            {
                if ($option)
                {
                    $section_id = \JNews\Customizer\CategoryOption::get_section_id($key);
                    $category_id = $key;

                    $result[$section_id][] = array(
                        'function' => array($this, 'category_builder'),
                        'parameter' => array($category_id)
                    );
                }
            }

            return $result;
        }

        public function category_builder($category_id)
        {
            include_once JNEWS_THEME_CLASSPATH . "Customizer/sections/single_category.php";
            return single_category_option($category_id);
        }

        protected function generate_theme_mod_filter( $customizer_key, $option_key, $term_id )
        {
            $tag   = 'theme_mod_' . $customizer_key . $term_id;
            $value = $this->get_value( $option_key, $term_id );

            add_filter( $tag, function($val) use ($value)
            {
                if ( ! empty( $value ) )
                {
                    $val = $value;
                }
                return $val;
            });
        }

        protected function is_overwritten( $term_id )
        {
            $option = get_option( $this->prefix . 'category_override' , array() );

            if ( isset( $option[$term_id] ) )
            {
                return $option[$term_id];
            }

            return false;
        }

        public function get_content_pagination_pageinfo( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_pagination_page' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_pagination_navtext( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_pagination_text' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_pagination_align( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_pagination_align' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_pagination_limit( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_pagination_limit' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_pagination( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_pagination' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_date_custom( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_date_custom' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_date( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_date' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_excerpt( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_excerpt' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_content_type( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'content_layout' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_hero_date_custom( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'hero_date_custom' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_hero_date( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'hero_date' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_hero_margin( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'hero_margin' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_hero_style( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'hero_style' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_hero_type( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'hero_layout' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_show_hero( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'show_hero' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_header_image( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'title_bg_image' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = wp_get_attachment_image_url( $new_option[$term_id], 'full' );
                }
            }

            return $option;
        }

        public function get_header_style( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'header_scheme' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_header_background( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'title_bg_color' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_header_type( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'header_style' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

	    public function get_category_boxed( $option, $term_id )
	    {
		    if ( $this->is_overwritten( $term_id ) )
		    {
			    $new_option = get_option( $this->prefix . 'content_boxed' );

			    if ( isset( $new_option[$term_id] ) )
			    {
				    $option = $new_option[$term_id];
			    }
		    }

		    return $option;
	    }

	    public function get_category_boxed_shadow( $option, $term_id )
	    {
		    if ( $this->is_overwritten( $term_id ) )
		    {
			    $new_option = get_option( $this->prefix . 'content_boxed_shadow' );

			    if ( isset( $new_option[$term_id] ) )
			    {
				    $option = $new_option[$term_id];
			    }
		    }

		    return $option;
	    }

	    public function get_category_box_shadow( $option, $term_id )
	    {
		    if ( $this->is_overwritten( $term_id ) )
		    {
			    $new_option = get_option( $this->prefix . 'content_box_shadow' );

			    if ( isset( $new_option[$term_id] ) )
			    {
				    $option = $new_option[$term_id];
			    }
		    }

		    return $option;
	    }

        public function get_content_page_layout( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'page_layout' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_sticky_sidebar( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'sticky_sidebar' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

        public function get_category_sidebar( $option, $term_id )
        {
            if ( $this->is_overwritten( $term_id ) )
            {
                $new_option = get_option( $this->prefix . 'sidebar' );

                if ( isset( $new_option[$term_id] ) )
                {
                    $option = $new_option[$term_id];
                }
            }

            return $option;
        }

	    public function get_category_second_sidebar( $option, $term_id )
	    {
		    if ( $this->is_overwritten( $term_id ) )
		    {
			    $new_option = get_option( $this->prefix . 'second_sidebar' );

			    if ( isset( $new_option[$term_id] ) )
			    {
				    $option = $new_option[$term_id];
			    }
		    }

		    return $option;
	    }

        public function load_script()
        {
            if ( $this->is_category_page() )
            {
                wp_enqueue_script('jquery-ui-spinner');
                wp_enqueue_style('jnews-widget-css',        JNEWS_THEME_URL . '/assets/css/admin/widget.css', null, jnews_get_theme_version());
                wp_enqueue_style('font-awesome',            JNEWS_THEME_URL . '/assets/fonts/font-awesome/font-awesome.min.css', null, jnews_get_theme_version());

                // upload
                wp_enqueue_media();

                // color picker
                wp_enqueue_style( 'wp-color-picker' );
                wp_enqueue_script( 'wp-color-picker-alpha', JEG_URL . '/assets/js/vendor/wp-color-picker-alpha.js', array( 'wp-color-picker' ), null, true );
            }
        }

        public function is_category_page()
        {
            return in_array($GLOBALS['pagenow'], array('term.php'));
        }

        public function render_options( $tag )
        {
            if ( ! defined('JNEWS_THEME_ID') || ! isset( $tag->term_id ) ) return false;

            $options        = $this->get_options();
            $title          = esc_html__('Override Category Setting', 'jnews-option-category');

            $output     = '';
            $term_id    = $tag->term_id;

            foreach ( $options as $key => $field )
            {
                if ( isset( $field['items'] ) )
                {
                    $output .=
                        "<div class='jeg_accordion_wrapper collapsible close widget_class {$key}'>" .
                            "<div class='jeg_accordion_heading'>
                                <span class='jeg_accordion_title'>{$field['title']}</span>
                                <span class='jeg_accordion_button'></span>
                            </div>" .
                            "<div class='jeg_accordion_body' style='display: none'>";

                    foreach ( $field['items'] as $key1 => $field1 )
                    {
                        $output .= FormControl::generate_form( $field1['type'], $this->setting_field( $key1, $field1, $term_id ) );
                    }

                    $output .= "</div></div>";

                } else {
                    $output .= FormControl::generate_form( $field['type'], $this->setting_field( $key, $field, $term_id ) );
                }
            }

            $output =
                "<div class='jeg_accordion_wrapper collapsible open widget_class " . sanitize_title($title) . "'>" .
                    "<div class='jeg_accordion_heading category'>
                        <span class='jeg_accordion_title'>{$title}</span>
                        <span class='jeg_accordion_button'></span>
                    </div>" .
                    "<div class='jeg_accordion_body'>" . $output . "</div>" .
                "</div>";

            echo $output;
        }

        protected function setting_field( $key, $field, $term_id )
        {
            $setting = array();

            $option = $this->get_value( $key, $term_id );

            $setting['title']       = isset($field['title']) ? $field['title'] : '';
            $setting['desc']        = isset($field['desc']) ? $field['desc'] : '';
            $setting['options']     = isset($field['options']) ? $field['options'] : array();
            $setting['fieldkey']    = $key;
            $setting['fieldid']     = $key . '_' . $term_id;
            $setting['fieldname']   = $key;
            $setting['default']     = isset($field['default']) ? $field['default'] : '';
            $setting['value']       = isset($option) ? $option : $setting['default'] ;
            $setting['fields']      = isset($field['fields']) ? $field['fields'] : array();
            $setting['row_label']   = isset($field['row_label']) ? $field['row_label'] : array();
            $setting['dependency']  = isset($field['dependency']) ? $field['dependency'] : array();

            return $setting;
        }

        public function save_category()
        {
            if ( isset( $_POST['taxonomy']) && $_POST['taxonomy'] === 'category' )
            {
                $options = $this->get_options();

                foreach ( $options as $key => $field )
                {
                    if ( isset( $field['items'] ) )
                    {
                        foreach ( $field['items'] as $key1 => $value1 )
                        {
                            $option = isset( $_POST[$key1] ) ? $_POST[$key1] : false;
                            $this->save_category_value( $key1, $_POST['tag_ID'], $option );
                        }
                    } else {
                        $option = isset( $_POST[$key] ) ? $_POST[$key] : false;
                        $this->save_category_value( $key, $_POST['tag_ID'], $option );
                    }

                    $this->generate_dynamic_style();
                }
            }
        }

        protected function generate_dynamic_style()
        {
            $style_instance = Jeg\Util\StyleGenerator::getInstance();
            $style_instance->remove_dynamic_file();
        }

        protected function get_value( $key, $term_id )
        {
            $value = get_option( $this->prefix . $key, false );

            if ( isset( $value[ $term_id ] ) )
            {
                return $value[ $term_id ];
            }
        }

        protected function save_category_value( $key, $term_id, $value )
        {
            $values = get_option( $this->prefix . $key, array() );

            $values[$term_id] = $value;

            update_option( $this->prefix . $key, $values );
        }

        protected function get_options()
        {
            $all_sidebar = apply_filters('jnews_get_sidebar_widget', null);

            $category_override = array(
                'field'     => 'category_override',
                'operator'  => '==',
                'value'     => true
            );

            $category_override_color = array(
                'field'     => 'category_override_color',
                'operator'  => '==',
                'value'     => true
            );

            return array (
                'category_override_color'  => array(
                    'title'     => esc_html__('Override Category Color', 'jnews-option-category'),
                    'desc'      => esc_html__('Override category general color setting.', 'jnews-option-category'),
                    'type'      => 'checkbox',
                    'default'   => false
                ),
                'category_color'  => array(
                    'title'     => esc_html__('Category Color', 'jnews-option-category'),
                    'items'     => array(
                        'category_bg_color' => array(
                            'title'     => esc_html__('Category Background Color', 'jnews-option-category'),
                            'desc'      => esc_html__('Main color for this category.', 'jnews-option-category'),
                            'default'   => '',
                            'type'      => 'colorpicker',
                            'dependency'    => array(
                                $category_override_color
                            )
                        ),
                        'category_text_color' => array(
                            'title'     => esc_html__('Category Text Color', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose text color for this category.', 'jnews-option-category'),
                            'default'   => '',
                            'type'      => 'colorpicker',
                            'dependency'    => array(
                                $category_override_color
                            )
                        )
                    )
                ),
                'category_override'  => array(
                    'title'     => esc_html__('Override Category Setting', 'jnews-option-category'),
                    'desc'      => esc_html__('Override category general setting.', 'jnews-option-category'),
                    'type'      => 'checkbox',
                    'default'   => false
                ),
                'category_sidebar'  => array(
                    'title'     => esc_html__('Category Page Layout', 'jnews-option-category'),
                    'items'   => array(
                        'page_layout'  => array(
                            'title'     => esc_html__('Page Layout', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose your page layout.', 'jnews-option-category'),
                            'default'   => 'right-sidebar',
                            'type'      => 'radioimage',
                            'options' => array(
	                            'right-sidebar'         => '',
	                            'left-sidebar'          => '',
	                            'right-sidebar-narrow'  => '',
	                            'left-sidebar-narrow'   => '',
	                            'double-sidebar'        => '',
	                            'double-right-sidebar'  => '',
	                            'no-sidebar'            => ''
                            ),
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'sidebar'           => array(
                            'title'         => esc_html__('Category Sidebar', 'jnews-option-category'),
                            'desc'          => wp_kses(__("Choose your category sidebar. If you need another sidebar, you can create from <strong>WordPress Admin</strong> &raquo; <strong>Appearance</strong> &raquo; <strong>Widget</strong>.", 'jnews-option-category'), wp_kses_allowed_html()),
                            'type'          => 'select',
                            'default'       => 'default-sidebar',
                            'options'       => $all_sidebar,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'page_layout',
                                    'operator'  => '!=',
                                    'value'     => 'no-sidebar'
                                )
                            )
                        ),
                        'second_sidebar'    => array(
	                        'title'         => esc_html__('Second Category Sidebar', 'jnews-option-category'),
	                        'desc'          => wp_kses(__("Choose your second sidebar for category page. If you need another sidebar, you can create from <strong>WordPress Admin</strong> &raquo; <strong>Appearance</strong> &raquo; <strong>Widget</strong>.", 'jnews-option-category'), wp_kses_allowed_html()),
	                        'type'          => 'select',
	                        'default'       => 'default-sidebar',
	                        'options'       => $all_sidebar,
	                        'dependency'    => array(
		                        $category_override,
		                        array(
			                        'field'     => 'page_layout',
			                        'operator'  => 'in',
			                        'value'     => array('double-sidebar', 'double-right-sidebar')
		                        )
	                        )
                        ),
                        'sticky_sidebar'    => array(
                            'title'         => esc_html__('Category Sticky Sidebar', 'jnews-option-category'),
                            'desc'          => esc_html__('Enable sticky sidebar on this category page.', 'jnews-option-category'),
                            'type'          => 'checkbox',
                            'default'       => true,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'page_layout',
                                    'operator'  => '!=',
                                    'value'     => 'no-sidebar'
                                )
                            )
                        )
                    )
                ),
                'category_header'   => array(
                    'title'     => esc_html__('Category Header', 'jnews-option-category'),
                    'items'     => array(
                        'header_style'  => array(
                            'title'     => esc_html__('Category Header Style', 'jnews-option-category'),
                            'desc'      => esc_html__('Category header: title and description type.', 'jnews-option-category'),
                            'default'   => '1',
                            'type'      => 'radioimage',
                            'options' => array(
                                '1' => '',
                                '2' => '',
                                '3' => '',
                                '4' => '',
                            ),
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'header_scheme' => array(
                            'title'     => esc_html__('Color Scheme', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose color for your category title background color.', 'jnews-option-category'),
                            'default'   => 'dark',
                            'type'      => 'select',
                            'options'   => array(
                                'dark'      => esc_html__('Dark Style', 'jnews-option-category'),
                                'normal'    => esc_html__('Normal Style (Light)', 'jnews-option-category')
                            ),
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'header_style',
                                    'operator'  => 'in',
                                    'value'     => array('3', '4')
                                )
                            )
                        ),
                        'title_bg_color' => array(
                            'title'     => esc_html__('Title Background Color', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose color for your category title background color.', 'jnews-option-category'),
                            'default'   => '#f5f5f5',
                            'type'      => 'colorpicker',
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'header_style',
                                    'operator'  => 'in',
                                    'value'     => array('3', '4')
                                )
                            )
                        ),
                        'title_bg_image' => array(
                            'title'     => esc_html__('Title Background Image', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose or upload image for your category background.', 'jnews-option-category'),
                            'default'   => '',
                            'type'      => 'image',
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'header_style',
                                    'operator'  => 'in',
                                    'value'     => array('3', '4')
                                )
                            )
                        )
                    )
                ),
                'category_hero'     => array(
                    'title'     => esc_html__('Category Hero', 'jnews-option-category'),
                    'items'   => array(
                        'show_hero'  => array(
                            'title'     => esc_html__('Show Category Hero Block', 'jnews-option-category'),
                            'desc'      => esc_html__('Disable this option to hide category hero block.', 'jnews-option-category'),
                            'type'      => 'checkbox',
                            'default'   => false,
                            'dependency'    => array(
                                $category_override,
                            )
                        ),
                        'hero_layout'  => array(
                            'title'     => esc_html__('Category Hero Header', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose your category header (hero).', 'jnews-option-category'),
                            'default'   => '1',
                            'type'      => 'radioimage',
                            'options' => array(
                                '1'  => '',
                                '2'  => '',
                                '3'  => '',
                                '4'  => '',
                                '5'  => '',
                                '6'  => '',
                                '7'  => '',
                                '8'  => '',
                                '9'  => '',
                                '10' => '',
                                '11' => '',
                                '12' => '',
                                '13' => '',
                                'skew' => '',
                            ),
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'show_hero',
                                    'operator'  => '==',
                                    'value'     => true
                                )
                            )
                        ),
                        'hero_style'  => array(
                            'title'     => esc_html__('Category Header Style', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose your category header (hero) style.', 'jnews-option-category'),
                            'default'   => 'jeg_hero_style_1',
                            'type'      => 'radioimage',
                            'options' => array(
                                'jeg_hero_style_1'  => '',
                                'jeg_hero_style_2'  => '',
                                'jeg_hero_style_3'  => '',
                                'jeg_hero_style_4'  => '',
                                'jeg_hero_style_5'  => '',
                                'jeg_hero_style_6'  => '',
                                'jeg_hero_style_7'  => '',
                            ),
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'show_hero',
                                    'operator'  => '==',
                                    'value'     => true
                                )
                            )
                        ),
                        'hero_margin'  => array(
                            'title'     => esc_html__('Hero Margin', 'jnews-option-category'),
                            'desc'      => esc_html__('Margin of each hero element.', 'jnews-option-category'),
                            'type'      => 'number',
                            'options'    => array(
                                'min'  => '0',
                                'max'  => '30',
                                'step' => '1',
                            ),
                            'default'   => 10,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'show_hero',
                                    'operator'  => '==',
                                    'value'     => true
                                )
                            )
                        ),
                        'hero_date' => array(
                            'title'     => esc_html__('Choose Date Format', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose which date format you want to use for category.', 'jnews-option-category'),
                            'default'   => 'default',
                            'type'      => 'select',
                            'options'   => array(
                                'ago'       => esc_html__( 'Relative Date/Time Format (ago)', 'jnews-option-category' ),
                                'default'   => esc_html__( 'WordPress Default Format', 'jnews-option-category' ),
                                'custom'    => esc_html__( 'Custom Format', 'jnews-option-category' ),
                            ),
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'show_hero',
                                    'operator'  => '==',
                                    'value'     => true
                                )
                            )
                        ),
                        'hero_date_custom' => array(
                            'title'     => esc_html__('Custom Date Format', 'jnews-option-category'),
                            'desc'      => wp_kses(sprintf(__("Please set custom date format for hero element. For more detail about this format, please refer to
                                        <a href='%s' target='_blank'>Developer Codex</a>.", "jnews-option-category"), "https://developer.wordpress.org/reference/functions/current_time/"),
                        wp_kses_allowed_html()),
                            'default'   => 'Y/m/d',
                            'type'      => 'text',
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'show_hero',
                                    'operator'  => '==',
                                    'value'     => true
                                ),
                                array(
                                    'field'     => 'hero_date',
                                    'operator'  => '==',
                                    'value'     => 'custom'
                                )
                            )
                        )
                    )
                ),
                'category_content'     => array(
                    'title'     => esc_html__('Category Content', 'jnews-option-category'),
                    'items'     => array(
                        'content_layout'  => array(
                            'title'     => esc_html__('Category Content Layout', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose your category content layout.', 'jnews-option-category'),
                            'default'   => '3',
                            'type'      => 'radioimage',
                            'options' => array(
                                '3'  => '',
                                '4'  => '',
                                '5'  => '',
                                '6'  => '',
                                '7'  => '',
                                '9'  => '',
                                '10' => '',
                                '11' => '',
                                '12' => '',
                                '14' => '',
                                '15' => '',
                                '18' => '',
                                '22' => '',
                                '23' => '',
                                '25' => '',
                                '26' => '',
                                '27' => '',
                                '32' => '',
                                '33' => '',
                                '34' => '',
                                '35' => '',
                                '36' => '',
                                '37' => '',
                            ),
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'content_boxed' => array(
	                        'title'     => esc_html__('Enable Boxed', 'jnews-option-category'),
	                        'desc'      => esc_html__('This option will turn the module into boxed.', 'jnews-option-category'),
	                        'type'      => 'checkbox',
	                        'default'   => false,
	                        'dependency'    => array(
		                        $category_override,
		                        array(
			                        'field'     => 'content_layout',
			                        'operator'  => 'in',
			                        'value'     => array('3','4','5','6','7','9','10','14','18','22','23','25','26','27')
		                        )
	                        )
                        ),
                        'content_boxed_shadow' => array(
	                        'title'     => esc_html__('Enable Shadow', 'jnews-option-category'),
	                        'desc'      => esc_html__('Enable shadow on the module template.', 'jnews-option-category'),
	                        'type'      => 'checkbox',
	                        'default'   => false,
	                        'dependency'    => array(
		                        $category_override,
		                        array(
			                        'field'     => 'content_boxed',
			                        'operator'  => '==',
			                        'value'     => true
		                        ),
		                        array(
			                        'field'     => 'content_layout',
			                        'operator'  => 'in',
			                        'value'     => array('3','4','5','6','7','9','10','14','18','22','23','25','26','27')
		                        )
	                        )
                        ),
                        'content_box_shadow' => array(
	                        'title'     => esc_html__('Enable Shadow', 'jnews-option-category'),
	                        'desc'      => esc_html__('Enable shadow on the module template.', 'jnews-option-category'),
	                        'type'      => 'checkbox',
	                        'default'   => false,
	                        'dependency'    => array(
		                        $category_override,
		                        array(
			                        'field'     => 'content_layout',
			                        'operator'  => 'in',
			                        'value'     => array('37','35','33','36','32','38')
		                        )
	                        )
                        ),
                        'content_excerpt'  => array(
                            'title'     => esc_html__('Excerpt Length', 'jnews-option-category'),
                            'desc'      => esc_html__('Set the word length of excerpt on post.', 'jnews-option-category'),
                            'type'      => 'number',
                            'options'    => array(
                                'min'  => '0',
                                'max'  => '200',
                                'step' => '1',
                            ),
                            'default'   => 20,
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'content_date' => array(
                            'title'     => esc_html__('Choose Date Format', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose which date format you want to use for category content element.', 'jnews-option-category'),
                            'default'   => 'default',
                            'type'      => 'select',
                            'options'   => array(
                                'ago'       => esc_html__( 'Relative Date/Time Format (ago)', 'jnews-option-category' ),
                                'default'   => esc_html__( 'WordPress Default Format', 'jnews-option-category' ),
                                'custom'    => esc_html__( 'Custom Format', 'jnews-option-category' ),
                            ),
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'content_date_custom' => array(
                            'title'     => esc_html__('Custom Date Format', 'jnews-option-category'),
                            'desc'      => wp_kses(sprintf(__("Please set custom date format for category content element. For more detail about this format, please refer to
                                        <a href='%s' target='_blank'>Developer Codex</a>.", "jnews-option-category"), "https://developer.wordpress.org/reference/functions/current_time/"),
                        wp_kses_allowed_html()),
                            'default'   => 'Y/m/d',
                            'type'      => 'text',
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'content_date',
                                    'operator'  => '==',
                                    'value'     => 'custom'
                                )
                            )
                        ),
                        'content_pagination' => array(
                            'title'     => esc_html__('Choose Pagination Mode', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose which pagination mode that fit with your block.', 'jnews-option-category'),
                            'default'   => 'nav_1',
                            'type'      => 'select',
                            'options'   => array(
                                'nav_1'         => esc_html__( 'Normal - Navigation 1', 'jnews-option-category' ),
                                'nav_2'         => esc_html__( 'Normal - Navigation 2', 'jnews-option-category' ),
                                'nav_3'         => esc_html__( 'Normal - Navigation 3', 'jnews-option-category' ),
                                'nextprev'      => esc_html__( 'Ajax - Next Prev', 'jnews-option-category' ),
                                'loadmore'      => esc_html__( 'Ajax - Load More', 'jnews-option-category' ),
                                'scrollload'    => esc_html__( 'Ajax - Auto Scroll Load', 'jnews-option-category' ),
                            ),
                            'dependency'    => array(
                                $category_override
                            )
                        ),
                        'content_pagination_limit' => array(
                            'title'     => esc_html__('Auto Load Limit', 'jnews-option-category'),
                            'desc'      => esc_html__('Limit of auto load when scrolling, set to zero to always load until end of content.', 'jnews-option-category'),
                            'type'      => 'number',
                            'options'    => array(
                                'min'  => '0',
                                'max'  => '9999',
                                'step' => '1',
                            ),
                            'default'   => 0,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'content_pagination',
                                    'operator'  => '==',
                                    'value'     => 'scrollload'
                                )
                            )
                        ),
                        'content_pagination_align' => array(
                            'title'     => esc_html__('Pagination Align', 'jnews-option-category'),
                            'desc'      => esc_html__('Choose pagination alignment.', 'jnews-option-category'),
                            'default'   => 'center',
                            'type'      => 'select',
                            'options'   => array(
                                'left'      => esc_html__( 'Left', 'jnews-option-category' ),
                                'center'    => esc_html__( 'Center', 'jnews-option-category' ),
                            ),
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'content_pagination',
                                    'operator'  => 'in',
                                    'value'     => array('nav_1', 'nav_2', 'nav_3')
                                )
                            )
                        ),
                        'content_pagination_text'  => array(
                            'title'     => esc_html__('Show Navigation Text', 'jnews-option-category'),
                            'desc'      => esc_html__('Show navigation text (next, prev).', 'jnews-option-category'),
                            'type'      => 'checkbox',
                            'default'   => false,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'content_pagination',
                                    'operator'  => 'in',
                                    'value'     => array('nav_1', 'nav_2', 'nav_3')
                                )
                            )
                        ),
                        'content_pagination_page'  => array(
                            'title'     => esc_html__('Show Page Info', 'jnews-option-category'),
                            'desc'      => esc_html__('Show page info text (Page x of y).', 'jnews-option-category'),
                            'type'      => 'checkbox',
                            'default'   => false,
                            'dependency'    => array(
                                $category_override,
                                array(
                                    'field'     => 'content_pagination',
                                    'operator'  => 'in',
                                    'value'     => array('nav_1', 'nav_2', 'nav_3')
                                )
                            )
                        )
                    )
                )
            );
        }
    }
}
